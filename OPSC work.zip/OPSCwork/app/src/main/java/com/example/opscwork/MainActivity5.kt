package com.example.opscwork

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.widget.Button
import android.widget.EditText
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase


class MainActivity5 : AppCompatActivity() {

    val db = Firebase.firestore
    //This points to the first collection
    val User = db.collection("User")
    //This point to the UserName
    val UserRef = User.document("Kailu")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main5)
        val minimumGoalEditText = findViewById<EditText>(R.id.minimumGoalEditText)
        val maximumGoalEditText = findViewById<EditText>(R.id.maximumGoalEditText)
        val saveButton = findViewById<Button>(R.id.saveButton)

        // Save button click listener
        saveButton.setOnClickListener()
        {
            val minimumGoalValue = minimumGoalEditText.text.toString().toInt()
            val maximumGoalValue = maximumGoalEditText.text.toString().toInt()
            //hashMap created to store goals data which will be sent to the database
            val mingoal =  hashMapOf("minGoal" to minimumGoalValue)
            val maxGoal  = hashMapOf("maxGoal" to maximumGoalValue)
            //Sets Goals
            UserRef.collection("Goals").document("minGoal").set(mingoal)
            UserRef.collection("Goals").document("maxGoal").set(maxGoal)
        }

        val toMenu: Button = findViewById(R.id.btn_toMenu)
        toMenu.setOnClickListener {
            val intent = Intent(this, Categories::class.java)
            startActivity(intent)
        }
    }
}
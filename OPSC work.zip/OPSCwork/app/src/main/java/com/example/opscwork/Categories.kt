package com.example.opscwork

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView


class Categories : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView
    private lateinit var drawerToggle: ActionBarDrawerToggle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_categories)

        val toTimesheet: Button = findViewById(R.id.btn_toTimesheet)
        toTimesheet.setOnClickListener {
            val intent = Intent(this, TimeSheetActivity::class.java)
            startActivity(intent)
        }

        val toDailyGoals: Button = findViewById(R.id.btn_toDailyGoals)
        toDailyGoals.setOnClickListener {
            val intent = Intent(this, MainActivity5::class.java)
            startActivity(intent)
        }

        val toLoadEntries: Button = findViewById(R.id.btn_toLoadEntries)
        toLoadEntries.setOnClickListener {
            val intent = Intent(this, MainActivity6::class.java)
            startActivity(intent)
        }

        val toTimePeriod: Button = findViewById(R.id.btn_toTimePeriod)
        toTimePeriod.setOnClickListener {
            val intent = Intent(this, Point7::class.java)
            startActivity(intent)
        }

        val toBarGraph: Button = findViewById(R.id.btn_toBarGraph)
        toBarGraph.setOnClickListener {
            val intent = Intent(this, BarChartActivity::class.java)
            startActivity(intent)
        }

        val toPieChart: Button = findViewById(R.id.btn_toPieChart)
        toPieChart.setOnClickListener {
            val intent = Intent(this, PieChartActivity::class.java)
            startActivity(intent)
        }

        val toRadarGraph: Button = findViewById(R.id.btn_toRadarGraph)
        toRadarGraph.setOnClickListener {
            val intent = Intent(this, RadarChartActivity::class.java)
            startActivity(intent)
        }

        val toGame: Button = findViewById(R.id.btn_toGame)
        toGame.setOnClickListener {
            val intent = Intent(this, Game::class.java)
            startActivity(intent)
        }
    }
}
package com.example.opscwork

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.opscwork.databinding.ActivityMainBinding
import com.example.opscwork.databinding.ActivitySignUpBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class SignUp : AppCompatActivity() {
    private lateinit var binding:ActivitySignUpBinding
    private lateinit var firebaseAuth: FirebaseAuth
    val db = Firebase.firestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //firebaseAuth = FirebaseAuth.getInstance()

        binding.toSignin.setOnClickListener {

            val intent = Intent(this , MainActivity::class.java)
            startActivity(intent)

        }

        binding.btnSignup.setOnClickListener{
            val username = binding.newUsername.text.toString()
            val password = binding.newPassword.text.toString()
            val confirmPassword = binding.retypePassword.text.toString()
            val pwordmap = hashMapOf(
                "password" to password
            )
///checks if the input values are there and if the match the passwords
            if (username.isNotEmpty() && password.isNotEmpty() && confirmPassword.isNotEmpty()) {
                if (password == confirmPassword) {
                    db.collection("Users").document(username).collection("pw").document("password")
                        .set(pwordmap).addOnCompleteListener {
                        if (it.isSuccessful) {
                            val intent = Intent(this , MainActivity::class.java)
                            startActivity(intent)

                        }else {
                            Toast.makeText(this, it.exception.toString(), Toast.LENGTH_SHORT).show()
                        }
                    }

                } else {
                    Toast.makeText(this, "The password does not match", Toast.LENGTH_SHORT).show()
                }
            }else{
                    Toast.makeText(this, "No fields may be left empty", Toast.LENGTH_SHORT).show()
                }
            }
        }





    }

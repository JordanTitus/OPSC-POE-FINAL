package com.example.opscwork

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.DatePicker
import android.widget.EditText
import android.widget.ImageView
import android.widget.TimePicker
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.*
import com.google.firebase.Timestamp
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class TimeSheetActivity : AppCompatActivity() {

    val db = Firebase.firestore
    private lateinit var datePickerDate: DatePicker
    private lateinit var timePickerStartTime: TimePicker
    private lateinit var timePickerEndTime: TimePicker
    private lateinit var editTextDescription: EditText
    private lateinit var editTextCategory: EditText
    private lateinit var buttonAddPhoto: Button
    private lateinit var imageViewPhoto: ImageView
    private lateinit var buttonSave: Button

    //This points to the first collection
    val User = db.collection("User")

    //This point to the UserName
    val UserRef = User.document("Kailu")

    //This points to the collection "Category"
    val Category = UserRef.collection("Category")

    companion object {
        private const val CAMERA_PERMISSION_REQUEST_CODE = 100
        private const val CAMERA_CAPTURE_REQUEST_CODE = 200
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.timesheet_activity)

        datePickerDate = findViewById<DatePicker>(R.id.datePickerDate)
        timePickerStartTime = findViewById(R.id.timePickerStartTime)
        timePickerEndTime = findViewById(R.id.timePickerEndTime)
        editTextDescription = findViewById(R.id.editTextDescription)
        editTextCategory = findViewById(R.id.editTextCategory)
        buttonAddPhoto = findViewById(R.id.buttonAddPhoto)
        imageViewPhoto = findViewById(R.id.imageViewPhoto)
        buttonSave = findViewById(R.id.buttonSave)

        buttonAddPhoto.setOnClickListener {
            checkCameraPermission()
        }

        buttonSave.setOnClickListener {
            saveTimeEntry()
        }

        val toMenu: Button = findViewById(R.id.btn_toMenu)
        toMenu.setOnClickListener {
            val intent = Intent(this, Categories::class.java)
            startActivity(intent)
        }
    }

    private fun checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            openCamera()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CAMERA),
                CAMERA_PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun openCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, CAMERA_CAPTURE_REQUEST_CODE)
    }

    private fun saveTimeEntry() {
        val year = datePickerDate.year
        val month = datePickerDate.month
        val day = datePickerDate.dayOfMonth

        // Create a Calendar instance and set the selected date
        val calendar = Calendar.getInstance()
        calendar.set(year, month, day)
        val selectedDate = calendar.time

        val startHour = timePickerStartTime.hour
        val endHour = timePickerEndTime.hour

        // Calculate the total hours
        val totalHours = startHour - endHour

        val description = editTextDescription.text.toString()
        val category = editTextCategory.text.toString()
        val photoPath = getImagePathFromImageView()
        val timestamp = Timestamp(selectedDate)

        // This points to the UserName
        val userRef = User.document("Kailu")

        // This points to the collection "Category"
        val categoryRef = userRef.collection("Category").document(category)

        // This points to the collection "TimeSheet"
        val timeSheetRef = categoryRef.collection("TimeSheet").document(description)

        // HashMap created to store timesheet data to be sent to the database
        val data = hashMapOf(
            "name" to description,
            "date" to timestamp,
            "photoId" to photoPath
        )

        // Set the data in the chosen timesheet
        timeSheetRef.set(data)
            .addOnSuccessListener {
                val intent = Intent(this, MainActivity6::class.java)
                intent.putExtra("description", description)
                intent.putExtra("category", category)
                intent.putExtra("photoPath", photoPath)
                startActivity(intent)
            }
            .addOnFailureListener { exception ->
                println("Error saving timesheet entry: $exception")
            }

        // Set the startTime, endTime, and total hours of the user
        val timeData = hashMapOf(
            "startTime" to startHour,
            "endTime" to endHour,
            "totalHours" to totalHours
        )

        timeSheetRef.collection("Time").document("Total Hours")
            .set(timeData)
            .addOnSuccessListener {
                // Success handling if needed
            }
            .addOnFailureListener { exception ->
                println("Error saving time data: $exception")
            }

        clearFields()
    }


    private fun clearFields() {
        editTextDescription.text.clear()
        editTextCategory.text.clear()
        imageViewPhoto.setImageDrawable(null)
        imageViewPhoto.visibility = View.GONE
    }

    private fun getImagePathFromImageView(): String? {
        val drawable = imageViewPhoto.drawable ?: return null
        val bitmap = (drawable as BitmapDrawable).bitmap
        val byteArrayOutputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream)
        val byteArray = byteArrayOutputStream.toByteArray()
        val file = File(filesDir, "time_entry_${System.currentTimeMillis()}.png")
        val fileOutputStream = FileOutputStream(file)
        fileOutputStream.write(byteArray)
        fileOutputStream.flush()
        fileOutputStream.close()
        return file.absolutePath
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            openCamera()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CAMERA_CAPTURE_REQUEST_CODE && resultCode == RESULT_OK) {
            val imageBitmap = data?.extras?.get("data") as Bitmap
            imageViewPhoto.setImageBitmap(imageBitmap)
            imageViewPhoto.visibility = View.VISIBLE
        }
    }
}

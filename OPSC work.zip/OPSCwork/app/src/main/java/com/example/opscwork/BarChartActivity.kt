package com.example.opscwork

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.utils.ColorTemplate
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FirebaseFirestore
import java.util.*

class BarChartActivity : AppCompatActivity() {

    private lateinit var barChart: BarChart
    private lateinit var timeFrameSpinner: Spinner
    private lateinit var nameEditText: EditText
    private lateinit var addEntryButton: Button
    private lateinit var generateButton: Button

    private val dataList: ArrayList<BarEntry> = ArrayList()
    private val nameList: ArrayList<String> = ArrayList()

    private lateinit var timeSheetRef: CollectionReference // Reference to the TimeSheet collection

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bar_chart)

        barChart = findViewById(R.id.bar_chart)
        timeFrameSpinner = findViewById(R.id.timeFrameSpinner)
        nameEditText = findViewById(R.id.nameEditText)
        addEntryButton = findViewById(R.id.addEntryButton)
        generateButton = findViewById(R.id.generateButton)

        val db = FirebaseFirestore.getInstance()
        timeSheetRef = db.collection("User")
            .document("Kailu")
            .collection("Category")
            .document("CategoryName")
            .collection("TimeSheet")

        val timeFrameAdapter = ArrayAdapter.createFromResource(
            this,
            R.array.time_frames,
            android.R.layout.simple_spinner_item
        )
        timeFrameAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        timeFrameSpinner.adapter = timeFrameAdapter

        addEntryButton.setOnClickListener {
            addEntry()
        }

        generateButton.setOnClickListener {
            generateChart()
        }

        val toMenu: Button = findViewById(R.id.btn_toMenu)
        toMenu.setOnClickListener {
            val intent = Intent(this, Categories::class.java)
            startActivity(intent)
        }
    }
        private fun addEntry() {
            val timeFrame = timeFrameSpinner.selectedItem.toString().toFloatOrNull()
            val value = (1..100).random().toFloat()
            val name = nameEditText.text.toString().trim()

            if (timeFrame != null && name.isNotEmpty()) {
                val entry = BarEntry(timeFrame, value)

                dataList.add(entry)
                nameList.add(name)
                nameEditText.text.clear()
            }
        }

        private fun generateChart() {
            val barDataSet = BarDataSet(dataList, "List")
            barDataSet.setColors(ColorTemplate.MATERIAL_COLORS, 255)
            barDataSet.valueTextColor = Color.BLACK

            val barData = BarData(barDataSet)

            barChart.setFitBars(true)
            barChart.data = barData
            barChart.description.text = "Bar Chart"
            barChart.animateY(2000)

            // Set the label for each bar using the timeframe name
            val xAxis = barChart.xAxis
            xAxis.valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    val entryIndex = value.toInt()
                    return if (entryIndex < nameList.size) nameList[entryIndex] else ""
                }
            }

            // Limit the number of visible bars based on the dataList size
            barChart.setVisibleXRangeMaximum(dataList.size.toFloat())
            barChart.setVisibleXRangeMinimum(dataList.size.toFloat())
            barChart.invalidate()
        }
    }


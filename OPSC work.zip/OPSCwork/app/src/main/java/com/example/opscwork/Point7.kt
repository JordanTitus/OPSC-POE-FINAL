package com.example.opscwork

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.DatePicker
import android.widget.EditText
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*
import com.example.opscwork.TimeEntry
import com.example.opscwork.TimeSheetActivity
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class Point7 : AppCompatActivity() {

    val db = Firebase.firestore
    //This points to the first collection
    val User = db.collection("User")

    //This point to the UserName
    val UserRef = User.document("Kailu")

    //This points to the collection "Category"
    val Category = UserRef.collection("Category")


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_point7)

        val btnSelectDate = findViewById<Button>(R.id.btnSelectDate)
        val etStartDate = findViewById<DatePicker>(R.id.etStartDate)
        val etEndDate = findViewById<DatePicker>(R.id.etEndDate)
        val tvTotalHoursByCategory = findViewById<TextView>(R.id.tvTotalHoursByCategory)
        // SelectDate button click listener
        btnSelectDate.setOnClickListener()
        {
            val startDate = etStartDate
            val endDate = etEndDate
            val categories = mutableListOf<String>()
            //Iterate over the total hours by category and display the results

            // Step 1: Query the categories
            db.collection("Users")
                .document("Kailu")
                .collection("Category")
                .get()
                .addOnSuccessListener { querySnapshot ->
                    for (document in querySnapshot.documents) {
                        val category = document.id
                        categories.add(category)
                    }

                    // Step 2: Retrieve total hours per category for the selected dates
                    for (category in categories) {
                        db.collection("Users")
                            .document("Kailu")
                            .collection("Category")
                            .document(category)
                            .collection("TimeSheet")
                            .whereGreaterThan("date", startDate)
                            .whereLessThan("date", endDate)
                            .get()
                            .addOnSuccessListener { querySnapshot ->
                                var totalHours = 0.0

                                for (document in querySnapshot.documents) {
                                    val hours = document.getDouble("Total Hours")
                                    if (hours != null) {
                                        totalHours += hours
                                    }
                                }


                            }
                            .addOnFailureListener { exception ->

                            }
                    }
                }
                .addOnFailureListener { exception ->

                }

            //Setting TextView equal to stringBuilder
            tvTotalHoursByCategory.text = ""
        }

    }
    fun onbtnToCategories(view: View){
        //val toCategories: Button = findViewById(R.id.btn_toCategories)
        //toCategories.setOnClickListener {
            val intent = Intent(this, Categories::class.java)

       // }

        startActivity(intent)
    }




//    private fun outsideFunction(entries: List<TimeEntry>) {
//        // Access and use the timeEntries list here
//        val allEntries: List<TimeEntry> = entries
//
//        // Your code to work with allEntries...
//    }
//    private fun calculateTotalHoursByCategory(startDate: Long, endDate: Long): Map<String, Float> {
//        //A mutable map called totalHoursByCategory is created to store the total hours spent on each category.
//        // The key of the map represents the category, and the value represents the total hours for that category.
//        val totalHoursByCategory = mutableMapOf<String, Float>()
//
//        for (entry in entries) {
//            val category = entry.category
//            // Custom method to calculate the hours between start and end times
//            //Look inside the TimesheetEntry Class
//            val hours = entry.calculateHours()
//
//            //Check if the map exists
//            //If it exists, add the hours to the value, otherwise create a new category with the hours.
//            if (totalHoursByCategory.containsKey(category)) {
//                totalHoursByCategory[category] = totalHoursByCategory[category]!! + hours
//            } else {
//                totalHoursByCategory[category] = hours
//            }
//        }
//
//        return totalHoursByCategory
//    }
}
//Website used to create mutableMapOf
//https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/mutable-map-of.html
//https://www.baeldung.com/kotlin/concatenate-strings
//https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.text/-string-builder/
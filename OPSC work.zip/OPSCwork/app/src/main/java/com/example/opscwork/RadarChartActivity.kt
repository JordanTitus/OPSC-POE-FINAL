package com.example.opscwork

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import com.github.mikephil.charting.charts.RadarChart
import com.github.mikephil.charting.data.RadarData
import com.github.mikephil.charting.data.RadarDataSet
import com.github.mikephil.charting.data.RadarEntry
import com.github.mikephil.charting.utils.ColorTemplate
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FirebaseFirestore

class RadarChartActivity : AppCompatActivity() {

    private lateinit var radarChart: RadarChart
    private lateinit var inputDataEditText: EditText
    private lateinit var addButton: Button
    private lateinit var generateButton: Button

    private val radarEntries: ArrayList<RadarEntry> = ArrayList()

    private lateinit var radarRef: CollectionReference // Reference to the Radar collection

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_radar_chart)



        radarChart = findViewById(R.id.radar_chart)
        inputDataEditText = findViewById(R.id.inputDataEditText)
        addButton = findViewById(R.id.addEntryButton)
        generateButton = findViewById(R.id.generateButton)

        val db = FirebaseFirestore.getInstance()
        radarRef = db.collection("User")
            .document("Kailu")
            .collection("Category")
            .document("CategoryName")
            .collection("Radar")

        addButton.setOnClickListener {
            addDataEntry()
        }

        generateButton.setOnClickListener {
            generateChart()
        }

        val toMenu: Button = findViewById(R.id.btn_toMenu)
        toMenu.setOnClickListener {
            val intent = Intent(this, Categories::class.java)
            startActivity(intent)
        }
    }

    private fun addDataEntry() {
        val inputData = inputDataEditText.text.toString()

        if (inputData.isNotEmpty()) {
            val value = inputData.toFloat()
            val entry = RadarEntry(value)
            radarEntries.add(entry)
            inputDataEditText.text.clear()
        }
    }

    private fun generateChart() {
        if (radarEntries.isNotEmpty()) {
            val radarDataSet = RadarDataSet(radarEntries, "List")
            radarDataSet.setColors(ColorTemplate.MATERIAL_COLORS, 255)
            radarDataSet.lineWidth = 2f
            radarDataSet.valueTextColor = Color.RED
            radarDataSet.valueTextSize = 14f

            val radarData = RadarData(radarDataSet)

            radarChart.data = radarData
            radarChart.description.text = "Radar Chart"
            radarChart.animateY(2000)

            // Save the radar entries to Firestore
            radarRef.document("Entries").set(radarEntries)
        }
    }


}

package com.example.opscwork

import java.text.SimpleDateFormat
import java.util.*

class TimeEntry(
    val date: String,
    val startTime: String,
    val endTime: String,
    val description: String,
    val category: String,
    val photoPath: String?
) {
    fun calculateHours(): Float {
        val startDateTime = parseDateTime(startTime)
        val endDateTime = parseDateTime(endTime)

        // Calculate the time difference between start and end times
        val durationInMillis = endDateTime.time - startDateTime.time
        return durationInMillis / (1000 * 60 * 60).toFloat()
    }

    private fun parseDateTime(time: String): Date {
        val dateFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
        return dateFormat.parse(time)
    }
}

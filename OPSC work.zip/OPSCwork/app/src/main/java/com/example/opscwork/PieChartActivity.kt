package com.example.opscwork

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.ColorTemplate
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FirebaseFirestore

class PieChartActivity : AppCompatActivity() {

    private lateinit var pieChart: PieChart
    private lateinit var inputDataEditText: EditText
    private lateinit var addButton: Button

    private val pieEntries: ArrayList<PieEntry> = ArrayList()

    private lateinit var pieRef: CollectionReference // Reference to the Pie collection

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pie_chart)

        pieChart = findViewById(R.id.pie_chart)
        inputDataEditText = findViewById(R.id.inputDataEditText)
        addButton = findViewById(R.id.addButton)

        val db = FirebaseFirestore.getInstance()
        pieRef = db.collection("User")
            .document("Kailu")
            .collection("Category")
            .document("CategoryName")
            .collection("Pie")

        addButton.setOnClickListener {
            addDataEntry()
        }

        val pieDataSet = PieDataSet(pieEntries, "List")
        pieDataSet.setColors(ColorTemplate.MATERIAL_COLORS, 255)
        pieDataSet.valueTextColor = Color.BLACK
        pieDataSet.valueTextSize = 15f

        val pieData = PieData(pieDataSet)

        pieChart.data = pieData
        pieChart.description.text = "Pie Chart"
        pieChart.centerText = "List"
        pieChart.animateY(2000)

        // Load existing entries from Firestore
        pieRef.document("Entries").get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    val existingEntries = document.toObject(ArrayList::class.java)
                    if (existingEntries != null) {
                        pieEntries.addAll(existingEntries as ArrayList<PieEntry>)
                        pieChart.data.notifyDataChanged()
                        pieChart.notifyDataSetChanged()
                        pieChart.invalidate()
                    }
                }
            }

        val toMenu: Button = findViewById(R.id.btn_toMenu)
        toMenu.setOnClickListener {
            val intent = Intent(this, Categories::class.java)
            startActivity(intent)
        }
    }
       private fun addDataEntry() {
            val inputData = inputDataEditText.text.toString()

            if (inputData.isNotEmpty()) {
                val value = (Math.random() * 100).toFloat()
                val entry = PieEntry(value, inputData)
                pieEntries.add(entry)
                pieChart.data.notifyDataChanged()
                pieChart.notifyDataSetChanged()
                pieChart.invalidate()

                // Save the updated entries to Firestore
                pieRef.document("Entries").set(pieEntries)
            }

            // Clear the input field
            inputDataEditText.text.clear()
        }
    }

